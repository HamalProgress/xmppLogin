//
//  CZBubbyView.h
//  XMPP
//
//  Created by wzh on 15/9/12.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CZBubbyView : UIView
@property (nonatomic,strong)UIImage *contentImage;
@property (nonatomic,strong)UIImageView *bigImageView;
@end
