//
//  CZBubbyView.m
//  XMPP
//
//  Created by wzh on 15/9/12.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import "CZBubbyView.h"

@implementation CZBubbyView


- (void)drawRect:(CGRect)rect {
    // Drawing code
//    UIImage *image = [UIImage imageNamed:@"BubbleImage"];
    [self.contentImage drawInRect:rect];
    
    
    UIImage *imageBubby = [UIImage imageNamed:@"SenderTextNodeBkg"];
    
    [imageBubby drawInRect:rect blendMode:kCGBlendModeDestinationIn alpha:1.0];
     
}

-(void)setContentImage:(UIImage *)contentImage{
    _contentImage = contentImage;
    [self setNeedsDisplay];
}

-(UIImageView *)bigImageView{
    if (_bigImageView == nil) {
        _bigImageView = [[UIImageView alloc]initWithImage:self.contentImage];
        _bigImageView.userInteractionEnabled = YES;
    }
    return _bigImageView;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    UIWindow *window = [[[UIApplication sharedApplication]delegate]window];
    
    CGRect newFrame = [self convertRect:self.frame toView:window];
    newFrame.origin.x = self.frame.origin.x;
    newFrame.origin.y -= 20;
    
    [self.bigImageView setFrame:newFrame];
    [self.bigImageView setImage:self.contentImage];
    [window addSubview:self.bigImageView];
    
    [UIView animateWithDuration:0.25 animations:^{
        [self.bigImageView setFrame:window.bounds];
    }];
    
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(cancelBigImageView)];
    [self.bigImageView addGestureRecognizer:tap];
    
}

- (void)cancelBigImageView{
    UIWindow *window = [[[UIApplication sharedApplication]delegate]window];
    
    CGRect newFrame = [self convertRect:self.frame toView:window];
    newFrame.origin.x = self.frame.origin.x;
    newFrame.origin.y -= 20;
    
    [UIView animateWithDuration:0.25 animations:^{
        [self.bigImageView setFrame:newFrame];
    }completion:^(BOOL finished) {
        [self.bigImageView removeFromSuperview];
    }];
    
    
}
@end
