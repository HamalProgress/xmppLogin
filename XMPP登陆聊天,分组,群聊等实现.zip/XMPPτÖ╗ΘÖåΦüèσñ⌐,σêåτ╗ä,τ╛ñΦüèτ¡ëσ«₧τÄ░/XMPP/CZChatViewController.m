//
//  CZCatViewController.m
//  XMPP
//
//  Created by wzh on 15/8/30.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import "CZChatViewController.h"
#import "CZBubbyView.h"

@interface CZChatViewController ()<UITableViewDelegate,UITableViewDataSource,XMPPStreamDelegate,XMPPOutgoingFileTransferDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (weak, nonatomic) IBOutlet UITableView *chatTableView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomLayout;
@property (weak, nonatomic) IBOutlet UITextField *textField;
@property (weak, nonatomic) IBOutlet UIButton *sendMessage;


- (IBAction)sendBtn:(id)sender;
- (IBAction)sendImage:(id)sender;

@property(strong,nonatomic)XMPPOutgoingFileTransfer *xmppOutgoingFileTransfer;

@property(strong,nonatomic)NSArray *messageArr;

@end

@implementation CZChatViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self fetchMessage];
    self.title = self.chatJid.bare;
    [[CZXMPPTool shardInstance].xmppStream addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fetchMessage) name:@"NewMessage" object:nil];


    
    
}

-(XMPPOutgoingFileTransfer *)xmppOutgoingFileTransfer{
    if(_xmppOutgoingFileTransfer == nil){
        _xmppOutgoingFileTransfer = [[XMPPOutgoingFileTransfer alloc]initWithDispatchQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        
        [_xmppOutgoingFileTransfer addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        
        [_xmppOutgoingFileTransfer activate:[CZXMPPTool shardInstance].xmppStream];
    }
    return _xmppOutgoingFileTransfer;
}


- (void)fetchMessage{
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 消息coredata(sqlite)的上下文
        NSManagedObjectContext *context = [CZXMPPTool shardInstance].xmppMessageArchivingCoreDataStorage.mainThreadManagedObjectContext;
        //    XMPPMessageArchiving_Message_CoreDataObject 所有消息的表
        //    XMPPMessageArchiving_Contact_CoreDataObject 最近联系人
        
        NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"XMPPMessageArchiving_Message_CoreDataObject"];
        
        
        NSPredicate *pre = [NSPredicate predicateWithFormat:@"bareJidStr = %@",self.chatJid.bareJID.bare];
        fetchRequest.predicate = pre;
        
        NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"timestamp" ascending:YES];
        fetchRequest.sortDescriptors = @[sort];
        
        NSArray *result = [context executeFetchRequest:fetchRequest error:nil];
        
        self.messageArr=result;
        [self.chatTableView reloadData];
        
        if (self.messageArr.count >2) {
            [self.chatTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:self.messageArr.count-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
        }
        
    });

}



#pragma mark datasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.messageArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    XMPPMessageArchiving_Message_CoreDataObject *messageObject = self.messageArr[indexPath.row];
    
    NSString *str = messageObject.isOutgoing ? @"MessageCellMe" : @"MessageCellOther";

    if ([messageObject.message.subject isEqualToString:@"IMAGE"]) {
        str = @"MessageCellMeImage";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:str];
        UIImageView *avartView = (UIImageView *)[cell viewWithTag:1001];
        NSData *avartData = [[CZXMPPTool shardInstance].xmppvCardAvatar photoDataForJID:[CZXMPPTool shardInstance].xmppStream.myJID];
        if (avartData !=nil) {
            avartView.image = [UIImage imageWithData:avartData];
            
            
        }
        
        NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
        
        path = [path stringByAppendingPathComponent:messageObject.message.body];
        
        
//        UIImageView *imageView = (UIImageView *)[cell viewWithTag:1003];
//        imageView.image = [UIImage imageWithData:[NSData dataWithContentsOfFile:path]];

        CZBubbyView *imageView = (CZBubbyView *)[cell viewWithTag:1003];
        imageView.contentImage = [UIImage imageWithData:[NSData dataWithContentsOfFile:path]];
        NSLog(@"---------PATH=%@",path);
        return cell;
    }
    
    
    
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:str];
    UIImageView *avartView = (UIImageView *)[cell viewWithTag:1001];

    UILabel *messageLable = (UILabel *)[cell viewWithTag:1002];
    UILabel *messageName = (UILabel *)[cell viewWithTag:1005];
    
    if(messageObject.isOutgoing != YES){
        NSData *avartData = [[CZXMPPTool shardInstance].xmppvCardAvatar photoDataForJID:messageObject.bareJid];
        avartView.image = [UIImage imageWithData:avartData];
    }else{
        
        
       NSData *data = [[CZXMPPTool shardInstance].xmppvCardTemp myvCardTemp].photo;
        
        NSData *avartData = [[CZXMPPTool shardInstance].xmppvCardAvatar photoDataForJID:[CZXMPPTool shardInstance].xmppStream.myJID];
        if (avartData !=nil) {
            avartView.image = [UIImage imageWithData:data];
        }
    }
    messageLable.text = messageObject.body;
    messageName.text = messageObject.bareJid.user;
    return cell;
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    XMPPMessageArchiving_Message_CoreDataObject *messageObject = self.messageArr[indexPath.row];
    if ([messageObject.message.subject isEqualToString:@"IMAGE"]) {
        return 172;
    }
    return 80;
}


-(void)xmppStream:(XMPPStream *)sender didSendMessage:(XMPPMessage *)message{
    [self fetchMessage];
}
-(void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message{
    if ([message.from.bare isEqualToString: self.chatJid.bare]) {
        [NSThread sleepForTimeInterval:0.1];
        [self fetchMessage];
    }

}
- (IBAction)sendBtn:(id)sender {
    
    
    XMPPMessage *message = [XMPPMessage messageWithType:@"chat" to:self.chatJid];
    [message addBody:self.textField.text];
    
    [[CZXMPPTool shardInstance].xmppStream sendElement:message];
    
    self.textField.text=@"";
}


- (IBAction)sendImage:(id)sender{
    UIImagePickerController *image = [[UIImagePickerController alloc]init];
    image.delegate=self;
    
    [self.navigationController presentViewController:image animated:YES completion:nil];
    
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    NSData *imageData = UIImageJPEGRepresentation(image, 0.1);
    
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    
    path = [path stringByAppendingPathComponent:[XMPPStream generateUUID]];
    path = [path stringByAppendingString:@".jpg"];
    [imageData writeToFile:path atomically:YES];
    
    XMPPMessage *message = [XMPPMessage messageWithType:@"chat" to:self.chatJid];
    
    [message addAttributeWithName:@"from" stringValue:[CZXMPPTool shardInstance].xmppStream.myJID.bare];
    
    [message addBody:[path lastPathComponent]];
    
    [message addSubject:@"IMAGE"];
    
    [[XMPPMessageArchivingCoreDataStorage sharedInstance] archiveMessage:message outgoing:YES xmppStream:[CZXMPPTool shardInstance].xmppStream];
    
    
    
    [self.xmppOutgoingFileTransfer sendData:imageData named:[path lastPathComponent] toRecipient:[XMPPJID jidWithUser:self.chatJid.user domain:self.chatJid.domain resource:@"iChat"] description:nil error:nil];
    [self fetchMessage];
    [picker dismissViewControllerAnimated:YES completion:nil];
}


-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}


-(void)xmppOutgoingFileTransferDidSucceed:(XMPPOutgoingFileTransfer *)sender{
 
    
}

@end
