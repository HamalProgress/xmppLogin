//
//  CZContactsTableViewController.h
//  XMPP
//
//  Created by wzh on 15/8/30.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CZContactsTableViewController : UITableViewController

@end
