//
//  CZContactsTableViewController.m
//  XMPP
//
//  Created by wzh on 15/8/30.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import "CZContactsTableViewController.h"
#import "CZChatViewController.h"

@interface CZContactsTableViewController ()<XMPPRosterDelegate,UIAlertViewDelegate,XMPPvCardAvatarDelegate>
@property (strong,nonatomic)NSMutableArray *contactsArr;
@end

@implementation CZContactsTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [[CZXMPPTool shardInstance].xmppRoster addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
    [[CZXMPPTool shardInstance].xmppRoster fetchRoster];// 整个程序中.只执行一次清点好友方法
    
    [[CZXMPPTool shardInstance].xmppStream addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
    
    
    [[CZXMPPTool shardInstance].xmppvCardAvatar addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
    

    
    /**
     *  1.程序运行时,点击到通讯录控制器时:向服务器清点人数
     
        2.接受别人添加
            如何知道别人添加了我们呢?
        
        3.你添加别人.
        
        4.删除别人.(取消订阅),别人删除你
     
     *
     *  @return <#return value description#>
     */
}



- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];
}

#pragma mark 通讯录的代理方法

/**
 * Sent when the initial roster is received.
 **/
- (void)xmppRosterDidBeginPopulating:(XMPPRoster *)sender{
    NSLog(@"CZContactsTableViewController开始更新通讯录");
}

/**
 * Sent when the initial roster has been populated into storage.
 **/
- (void)xmppRosterDidEndPopulating:(XMPPRoster *)sender{
   
    
    
    /**
     *  搜索coreData数据库
        1.需要上下文context
        2.创建一个搜索请求类,设置对应的实体名(XMPPUserCoreDataStorageObject)
        3.添加搜索条件(subscription = both 互相订阅)
        4.添加排序.(jid按升序排列)
     *
     *  @param NSInteger <#NSInteger description#>
     *
     *  @return <#return value description#>
     */
    
    [self fetchContacts];

}



- (void) fetchContacts{
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSManagedObjectContext *rosterContext = [CZXMPPTool shardInstance].xmppRosterCoreDataStrorage.mainThreadManagedObjectContext;
        NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"XMPPUserCoreDataStorageObject"];
        NSPredicate *pre = [NSPredicate predicateWithFormat:@"subscription = 'both'"];
        NSSortDescriptor *sort= [NSSortDescriptor sortDescriptorWithKey:@"jidStr" ascending:YES];
        
        fetchRequest.predicate = pre;
        fetchRequest.sortDescriptors = @[sort];
        
        
        NSArray *result = [rosterContext executeFetchRequest:fetchRequest error:nil];
        
        self.contactsArr =(NSMutableArray *) result;
        [self.tableView reloadData];
       
    });
}






#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.contactsArr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ContactCell"];
    XMPPUserCoreDataStorageObject  *userObject = self.contactsArr[indexPath.row];
    
    UILabel *lableJid = (UILabel *)[cell viewWithTag:10002];
    lableJid.text =userObject.jidStr;
    
    UIImageView *imageView = (UIImageView *)[cell viewWithTag:10001];
   
    // 获得别人的头像
    NSData *avatarData = [[CZXMPPTool shardInstance].xmppvCardAvatar photoDataForJID:userObject.jid];
    
    
    if (avatarData) {
        //还没激活头像模块,因此头像是空的
        imageView.image = [UIImage imageWithData:avatarData];
    }
    
//    
//     NSData *photoData =[[CZXMPPTool shardInstance].xmppvCardAvatar photoDataForJID:userObject.jid];
//    //还没激活头像模块,因此头像是空的
//    [imageView setImage:[UIImage imageWithData:photoData]];
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/


// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
       XMPPUserCoreDataStorageObject *userObject = self.contactsArr[indexPath.row];
        [[CZXMPPTool shardInstance].xmppRoster removeUser:userObject.jid];
        [self fetchContacts];
    }
}

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/



// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(UITableViewCell *)sender {
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:sender];
    XMPPUserCoreDataStorageObject *user = self.contactsArr[indexPath.row];
    CZChatViewController *chatVC= segue.destinationViewController;
    chatVC.chatJid =user.jid;
    
}



#pragma mark - 添加好友&UIAlertView的代理
- (IBAction)addFrend:(id)sender {
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"添加好友" message:@"好友的JID" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    [alert show];
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    UITextField *textField=[alertView textFieldAtIndex:0];
    if (buttonIndex ==0) {
        return;
    }
    
    NSString *jidStr = [NSString stringWithFormat:@"%@@itcast.cn",textField.text];
    
    [[CZXMPPTool shardInstance].xmppRoster addUser:[XMPPJID jidWithString:jidStr] withNickname:nil];
}

// 通过服务器发送过来的 presence 节点来判断
//    type = subscribe 别人添加你好友
//    type = unsubscribe 别人取消你的订阅信息
- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence{
    if([presence.type isEqualToString:@"subscribe"]){
        NSLog(@"当别人想添加你的时候,会进入这个判断. %@",presence);
        [NSThread sleepForTimeInterval:0.1];
        [self fetchContacts];


    }
    if([presence.type isEqualToString:@"unsubscribe"]){
        NSLog(@"当别人想取消你的订阅信息的时候,会进入这个判断. %@",presence);
        [NSThread sleepForTimeInterval:0.1];
        [self fetchContacts];
    }
    
    
}



#pragma mark 头像的代理方法
- (void)xmppvCardAvatarModule:(XMPPvCardAvatarModule *)vCardTempModule
              didReceivePhoto:(UIImage *)photo
                       forJID:(XMPPJID *)jid{
//    [self.tableView reloadData];
    [self fetchContacts];
}

@end
