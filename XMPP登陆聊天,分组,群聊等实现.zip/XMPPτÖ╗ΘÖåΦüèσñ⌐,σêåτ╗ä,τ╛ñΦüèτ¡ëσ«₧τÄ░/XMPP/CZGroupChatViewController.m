//
//  CZGroupChatViewController.m
//  XMPP
//
//  Created by wzh on 15/9/12.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import "CZGroupChatViewController.h"

@interface CZGroupChatViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (weak,nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bottomLayout;
@property (nonatomic, strong) NSArray *groupMessage;
@property (nonatomic, strong) NSMutableDictionary *jidDic;
@property (nonatomic, strong) XMPPRoom *roomModule;

@end

@implementation CZGroupChatViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self fetchGroupMessage];
}
- (XMPPRoom *)roomModule {
    if (!_roomModule) {
        _roomModule = [CZGroupManager sharedInstance].roomDic[self.roomJID.bare];
    }
    return _roomModule;
}

- (NSMutableDictionary *)jidDic {
    if (!_jidDic) {
        _jidDic = [NSMutableDictionary dictionary];
        //去成员表中查询出来 对应关系
        XMPPRoomCoreDataStorage * storage = [XMPPRoomCoreDataStorage sharedInstance];
        NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"XMPPRoomOccupantCoreDataStorageObject" inManagedObjectContext:storage.mainThreadManagedObjectContext];
        [fetchRequest setEntity:entity];
        // Specify criteria for filtering which objects to fetch
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"roomJIDStr = %@", self.roomJID.bare];
        [fetchRequest setPredicate:predicate];
        // Specify how the fetched objects should be sorted
        
        NSError *error = nil;
        NSArray *fetchedObjects = [storage.mainThreadManagedObjectContext executeFetchRequest:fetchRequest error:&error];
        if (fetchedObjects == nil) {
            //
        }
        for (XMPPRoomOccupantCoreDataStorageObject * occupant in fetchedObjects) {
            //假JID做key,真JID做value
            _jidDic [occupant.jidStr] = occupant.realJID;
        }
    }
    return _jidDic;
    
    
    
}


-(void)fetchGroupMessage {
//    XMPPRoomMessageCoreDataStorageObject
    NSFetchRequest *fetchRequest  = [NSFetchRequest fetchRequestWithEntityName:@"XMPPRoomMessageCoreDataStorageObject"];
    NSPredicate *pre= [NSPredicate predicateWithFormat:@"roomJIDStr =%@",self.roomJID.bare];
    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"localTimestamp" ascending:YES];
    
    fetchRequest.predicate = pre;
    fetchRequest.sortDescriptors = @[sort];
    
    NSArray *result = [[XMPPRoomCoreDataStorage sharedInstance].mainThreadManagedObjectContext executeFetchRequest:fetchRequest error:nil];
    
    self.groupMessage = result;
    [self.tableView reloadData];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  self.groupMessage.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    //群聊消息coredata对象
    XMPPRoomMessageCoreDataStorageObject *msg=self.groupMessage[indexPath.row];
    NSString *identifer=msg.isFromMe?@"MessageCellMe":@"MessageCellOther";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifer];
    
    UILabel *label = (UILabel *) [cell viewWithTag:1002];
    UIImageView * avatar = (UIImageView *)[cell viewWithTag:1001];
    if (msg.isFromMe) {
        UIImage *avatarImage=[UIImage imageWithData:[[CZXMPPTool shardInstance].xmppvCardTemp myvCardTemp].photo];
        
        [avatar setImage:avatarImage];
    }else{

        UIImage *avatarImage=[UIImage imageWithData:[[CZXMPPTool shardInstance].xmppvCardTemp vCardTempForJID:self.jidDic[msg.jidStr] shouldFetch:NO].photo];
        [avatar setImage:avatarImage];
        UILabel * nicklabel =(UILabel *) [cell viewWithTag:1005];
        [nicklabel setText:msg.nickname];
    }
    
    [label setText:msg.body];
    
    return cell;
}



#pragma mark - 群聊委托

- (void)xmppRoom:(XMPPRoom *)sender didReceiveMessage:(XMPPMessage *)message fromOccupant:(XMPPJID *)occupantJID{
    //消息一收到马上去查,可能会数据库还没存好 继续给它0.01秒的延迟 错开同时性
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.01 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self fetchGroupMessage];
    });
    
}

@end
