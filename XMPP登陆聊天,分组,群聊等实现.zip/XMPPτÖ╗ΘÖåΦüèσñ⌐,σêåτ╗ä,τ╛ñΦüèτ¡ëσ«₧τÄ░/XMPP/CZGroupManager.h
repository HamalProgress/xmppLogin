//
//  CZGroupManager.h
//  XMPP
//
//  Created by wzh on 15/9/13.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CZGroupManager : NSObject
@property (nonatomic, strong) NSMutableDictionary *roomDic;

+(instancetype)sharedInstance;
-(void)joinOrCreateWithRoomJid:(XMPPJID *)roomJid;
@end
