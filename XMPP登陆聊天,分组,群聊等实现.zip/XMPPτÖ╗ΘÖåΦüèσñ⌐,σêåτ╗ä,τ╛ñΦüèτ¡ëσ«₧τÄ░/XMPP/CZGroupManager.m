//
//  CZGroupManager.m
//  XMPP
//
//  Created by wzh on 15/9/13.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import "CZGroupManager.h"

@interface CZGroupManager() <XMPPRoomDelegate>

@end

@implementation CZGroupManager
static CZGroupManager *_manager;
+(instancetype)sharedInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _manager = [CZGroupManager new];
    });
    return _manager;
}

- (NSMutableDictionary *)roomDic{
    if (!_roomDic) {
        _roomDic = [NSMutableDictionary dictionary];
    }
    return _roomDic;
}

-(void)joinOrCreateWithRoomJid:(XMPPJID *)roomJid{
    if (!self.roomDic[roomJid.bare]) {
       
        XMPPRoom * room = [[XMPPRoom alloc]initWithRoomStorage:[XMPPRoomCoreDataStorage sharedInstance] jid:roomJid];
        [room addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0)];
        [room activate:[CZXMPPTool shardInstance].xmppStream];
    
        [room joinRoomUsingNickname:@"ios上的ZHANGSAN" history:nil];
        self.roomDic[roomJid.bare] = room;
    }
}

// 创建房间时进入此代理
-(void)xmppRoomDidCreate:(XMPPRoom *)sender{
    [sender configureRoomUsingOptions:nil];
    
    [sender inviteUser:[XMPPJID jidWithUser:@"spark" domain:@"itcast.cn" resource:nil] withMessage:@"zhangsan邀请你加入..."];
    NSLog(@"xmppRoomDidCreate");
    
}

// 加入房间时进入此代理
-(void)xmppRoomDidJoin:(XMPPRoom *)sender{
    NSLog(@"xmppRoomDidJoin");
}

@end
