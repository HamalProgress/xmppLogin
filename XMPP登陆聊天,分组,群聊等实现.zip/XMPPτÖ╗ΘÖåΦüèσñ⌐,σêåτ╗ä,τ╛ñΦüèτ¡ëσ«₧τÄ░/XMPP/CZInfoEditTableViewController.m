//
//  HMInfoEditTableViewController.m
//  02-仿微信
//
//  Created by apple on 15/4/10.
//  Copyright (c) 2015年 heima. All rights reserved.
//

#import "CZInfoEditTableViewController.h"

@interface CZInfoEditTableViewController ()
- (IBAction)cancelSave:(id)sender;
- (IBAction)ensureSave:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *textfield;
@end

@implementation CZInfoEditTableViewController
- (void)viewDidLoad {
    [super viewDidLoad];
   XMPPvCardTemp *myvCard = [[CZXMPPTool shardInstance].xmppvCardTemp myvCardTemp];
    
    if ([self.title isEqualToString:@"名称"]) {
        self.textfield.text = myvCard.nickname;
    }
    
    
    if ([self.title isEqualToString:@"个人签名"]) {
        self.textfield.text = myvCard.desc;
    }

}

- (IBAction)cancelSave:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)ensureSave:(id)sender {

    XMPPvCardTemp *myvCard = [[CZXMPPTool shardInstance].xmppvCardTemp myvCardTemp];

    if ([self.title isEqualToString:@"名称"]) {
         myvCard.nickname = self.textfield.text;
    }
    
    
    if ([self.title isEqualToString:@"个人签名"]) {
         myvCard.desc = self.textfield.text;
    }
    
    [[CZXMPPTool shardInstance].xmppvCardTemp updateMyvCardTemp:myvCard];
    [self.navigationController popViewControllerAnimated:YES];

}
@end
