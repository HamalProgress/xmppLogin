//
//  CZMainTableViewController.h
//  XMPP
//
//  Created by wzh on 15/8/31.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CZMainTableViewController : UITableViewController

@end
