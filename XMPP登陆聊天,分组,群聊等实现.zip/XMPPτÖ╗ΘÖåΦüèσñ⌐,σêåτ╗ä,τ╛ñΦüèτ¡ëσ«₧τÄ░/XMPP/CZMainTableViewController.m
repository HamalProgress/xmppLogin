//
//  CZMainTableViewController.m
//  XMPP
//
//  Created by wzh on 15/8/31.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import "CZMainTableViewController.h"
#import "CZGroupChatViewController.h"
#import "CZChatViewController.h"

@interface CZMainTableViewController ()<XMPPStreamDelegate,XMPPRoomDelegate,UIAlertViewDelegate>
@property (strong,nonatomic)NSArray *contactsArr;
@end

@implementation CZMainTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    [self fetchMessageContact];
    [[CZXMPPTool shardInstance].xmppStream addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
}


- (void)fetchMessageContact{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSManagedObjectContext *context=  [CZXMPPTool shardInstance].xmppMessageArchivingCoreDataStorage.mainThreadManagedObjectContext;
        //    XMPPMessageArchiving_Contact_CoreDataObject
        
        NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"XMPPMessageArchiving_Contact_CoreDataObject"];
        
        NSSortDescriptor *sort =[NSSortDescriptor sortDescriptorWithKey:@"mostRecentMessageTimestamp" ascending:NO];
        fetchRequest.sortDescriptors = @[sort];
        
        NSArray *result =[context executeFetchRequest:fetchRequest error:nil];
        
        self.contactsArr = result;
        [self.tableView reloadData];
    });
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.contactsArr.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"RecentContactCell"];
    
    XMPPMessageArchiving_Contact_CoreDataObject *contact = self.contactsArr[indexPath.row];
    
    UIImageView *avatar = (UIImageView *)[cell viewWithTag:1001];
    UIImage *avatarImage=[UIImage imageWithData:[[CZXMPPTool shardInstance].xmppvCardTemp vCardTempForJID:contact.bareJid shouldFetch:NO].photo];
    [avatar setImage:avatarImage];
    UILabel *lableUserName = (UILabel *)[cell viewWithTag:1002];
    lableUserName.text = contact.bareJidStr;
    UILabel *lableUserMessage = (UILabel *)[cell viewWithTag:1003];
    lableUserMessage.text = contact.mostRecentMessageBody;
    UILabel *lableUserDate = (UILabel *)[cell viewWithTag:1004];
    lableUserDate.text = [NSString stringWithFormat:@"%@",contact.mostRecentMessageTimestamp.description] ;

    
    
    return cell;
}


#pragma mark 
- (void)xmppStream:(XMPPStream *)sender didSendMessage:(XMPPMessage *)message{
    [NSThread sleepForTimeInterval:0.1];
    [self fetchMessageContact];
}

- (void)xmppStream:(XMPPStream *)sender didReceiveMessage:(XMPPMessage *)message{
    [NSThread sleepForTimeInterval:0.1];
    [self fetchMessageContact];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    XMPPMessageArchiving_Contact_CoreDataObject *contact = self.contactsArr[indexPath.row];
    if ([contact.bareJid.domain isEqualToString:@"conference.itcast.cn"]) {
        [self  performSegueWithIdentifier:@"groupChat" sender:contact];
    }else{
        [self  performSegueWithIdentifier:@"singleChat" sender:contact];

    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(XMPPMessageArchiving_Contact_CoreDataObject *)sender {
   
    if ([segue.identifier isEqualToString:@"groupChat"]) {
        CZGroupChatViewController *groupVC = segue.destinationViewController;
        groupVC.roomJID = sender.bareJid;
    }else{
        CZChatViewController *chatVc= segue.destinationViewController;
        chatVc.chatJid =sender.bareJid;
    }

    
}



#pragma mark --群聊
- (IBAction)joinOrCreateGroup:(id)sender {
    

    UIAlertView *as= [[UIAlertView alloc]initWithTitle:@"创建聊天室" message:@"请输入聊天室的名字" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
    as.delegate = self;
    as.alertViewStyle = UIAlertViewStylePlainTextInput;
    [as show];
    
    


}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) {
       UITextField *textFile = [alertView textFieldAtIndex:0];
        
        XMPPJID *roomJID = [XMPPJID jidWithUser:textFile.text domain:@"conference.itcast.cn" resource:nil];
        [[CZGroupManager sharedInstance] joinOrCreateWithRoomJid:roomJID];
    }
}



@end
