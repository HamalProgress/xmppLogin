//
//  HMMeTableViewController.m
//  02-仿微信
//
//  Created by apple on 15/4/10.
//  Copyright (c) 2015年 heima. All rights reserved.
//

#import "CZMeTableViewController.h"

@interface CZMeTableViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *myAvatar;
@property (weak, nonatomic) IBOutlet UILabel *myNickname;
@property (weak, nonatomic) IBOutlet UILabel *myJID;
@property (nonatomic,strong)XMPPvCardTemp *myvCardTemp;
@end

@implementation CZMeTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.myvCardTemp = [[CZXMPPTool shardInstance].xmppvCardTemp myvCardTemp];
    self.myNickname.text = self.myvCardTemp.nickname;
//    myvCard中的JID是空值
//    self.myJID.text= self.myvCardTemp.jid.bare;
    self.myJID.text =[[CZXMPPTool shardInstance].xmppStream myJID].bare;
    self.myAvatar.image = [UIImage imageWithData:self.myvCardTemp.photo];
  
}


@end
