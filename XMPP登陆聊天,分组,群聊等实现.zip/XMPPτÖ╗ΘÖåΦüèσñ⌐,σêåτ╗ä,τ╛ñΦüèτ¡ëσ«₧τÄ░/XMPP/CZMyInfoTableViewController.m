//
//  HMMyInfoTableViewController.m
//  02-仿微信
//
//  Created by apple on 15/4/10.
//  Copyright (c) 2015年 heima. All rights reserved.
//

#import "CZMyInfoTableViewController.h"

@interface CZMyInfoTableViewController ()<UIActionSheetDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,XMPPvCardAvatarDelegate>

@property (weak, nonatomic) IBOutlet UIImageView *myAvatar;
@property (weak, nonatomic) IBOutlet UILabel *myNickname;   //名字
@property (weak, nonatomic) IBOutlet UILabel *myJID;        //微信号
@property (weak, nonatomic) IBOutlet UILabel *myAddress;    //我的地址

@property (weak, nonatomic) IBOutlet UILabel *myGender;     //性别
@property (weak, nonatomic) IBOutlet UILabel *myCity;       //地区
@property (weak, nonatomic) IBOutlet UILabel *myDesc;       //个性签名

@end

@implementation CZMyInfoTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    XMPPvCardTemp *myvCardTemp = [[CZXMPPTool shardInstance].xmppvCardTemp myvCardTemp];
//    [[CZXMPPTool shardInstance].xmppvCardTemp addDelegate:self delegateQueue:dispatch_get_main_queue()];
//    
//    self.myAvatar.image = [UIImage imageWithData:myvCardTemp.photo];
//    
//    self.myNickname.text = myvCardTemp.nickname;
//    //    myvCard中的JID是空值
//    //    self.myJID.text= self.myvCardTemp.jid.bare;
//    self.myJID.text =[[CZXMPPTool shardInstance].xmppStream myJID].bare;
//    self.myAddress.text = [myvCardTemp.addresses lastObject];
////    ...
//    self.myDesc.text = myvCardTemp.desc;

    [self updatevCard];
    
}


-(void)updatevCard{
    XMPPvCardTemp *myvCardTemp = [[CZXMPPTool shardInstance].xmppvCardTemp myvCardTemp];
    [[CZXMPPTool shardInstance].xmppvCardAvatar addDelegate:self delegateQueue:dispatch_get_main_queue()];
    
    self.myAvatar.image = [UIImage imageWithData:myvCardTemp.photo];
    
    self.myNickname.text = myvCardTemp.nickname;
    //    myvCard中的JID是空值
    //    self.myJID.text= self.myvCardTemp.jid.bare;
    self.myJID.text =[[CZXMPPTool shardInstance].xmppStream myJID].bare;
    self.myAddress.text = [myvCardTemp.addresses lastObject];
    //    ...
    self.myDesc.text = myvCardTemp.desc;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    CZInfoEditTableViewController *editVC = segue.destinationViewController;
    
    if ([segue.identifier isEqualToString:@"nickname"]) {
        editVC.title = @"名称";
    }
    if ([segue.identifier isEqualToString:@"desc"]) {
        editVC.title = @"个人签名";
    }
    
    
}




- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0 && indexPath.section == 0) {
        UIActionSheet *as=[[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照",@"从相册中选择", nil];
        [as showFromTabBar:self.tabBarController.tabBar];
    }
    
    
}
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    UIImagePickerController *imageVC= [[UIImagePickerController alloc]init];
    if (buttonIndex == 0) {
        imageVC.sourceType = UIImagePickerControllerSourceTypeCamera;
    }
    imageVC.allowsEditing = YES;
    imageVC.delegate = self;
    [self.navigationController presentViewController:imageVC animated:YES completion:nil];
    
}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    XMPPvCardTemp *myvCard =[[CZXMPPTool shardInstance].xmppvCardTemp myvCardTemp];
    UIImage *image = info[UIImagePickerControllerEditedImage];
    myvCard.photo =UIImageJPEGRepresentation(image, 0.1);
    [[CZXMPPTool shardInstance].xmppvCardTemp updateMyvCardTemp:myvCard];
    
    [picker dismissViewControllerAnimated:YES completion:nil];
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{

    [picker dismissViewControllerAnimated:YES completion:nil];
}


- (void)xmppvCardAvatarModule:(XMPPvCardAvatarModule *)vCardTempModule
              didReceivePhoto:(UIImage *)photo
                       forJID:(XMPPJID *)jid{
    [self updatevCard];
}

@end
