//
//  CZXMPPTool.h
//  
//
//  Created by wzhmac on 15/8/19.
//
//

#import <Foundation/Foundation.h>
#import "DDLog.h"
#import "DDTTYLogger.h"
#import "XMPPLogging.h"


@interface CZXMPPTool : NSObject<XMPPStreamDelegate,XMPPAutoPingDelegate,XMPPReconnectDelegate,XMPPRosterDelegate,XMPPvCardTempModuleDelegate,XMPPvCardAvatarDelegate,XMPPIncomingFileTransferDelegate>
// xmpp发送数据的主要流
@property(strong,nonatomic)XMPPStream *xmppStream;
// 添加心跳包模块
@property(strong,nonatomic)XMPPAutoPing *xmppAutoPing;
// 添加自动重连模块
@property(strong,nonatomic)XMPPReconnect *xmppReconnect;

// 通讯录模块
@property(strong,nonatomic)XMPPRoster *xmppRoster;
// 通讯录存储类
@property(strong,nonatomic)XMPPRosterCoreDataStorage *xmppRosterCoreDataStrorage;

// 消息模块(最近联系人)
@property(strong,nonatomic)XMPPMessageArchiving *xmppMessageArchiving;
@property(strong,nonatomic)XMPPMessageArchivingCoreDataStorage *xmppMessageArchivingCoreDataStorage;

// 个人名片模块
@property(strong,nonatomic)XMPPvCardTempModule *xmppvCardTemp;
@property(strong,nonatomic)XMPPvCardCoreDataStorage *xmppvCardCoreDataStorage;
@property(strong,nonatomic)XMPPvCardAvatarModule *xmppvCardAvatar;


// 文件小助手

// 接收文件
@property(strong,nonatomic)XMPPIncomingFileTransfer *xmppIncomingFileTransfer;
@property(strong,nonatomic)XMPPOutgoingFileTransfer *xmppOutgoingFileTransfer;


+(instancetype)shardInstance;

//-(void)loginWithMyJid:(XMPPJID *)myJid withPassword:(NSString *)password;
@end
