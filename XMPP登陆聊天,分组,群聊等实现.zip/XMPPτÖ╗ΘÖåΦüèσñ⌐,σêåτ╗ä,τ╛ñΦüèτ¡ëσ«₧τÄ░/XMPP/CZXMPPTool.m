//
//  CZXMPPTool.m
//  
//
//  Created by wzhmac on 15/8/19.
//
//

#import "CZXMPPTool.h"

@implementation CZXMPPTool
static CZXMPPTool *_instance;
+(instancetype)shardInstance{
   static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [CZXMPPTool new];
    });
    return _instance;
}



#pragma mark 懒加载
-(XMPPStream *)xmppStream{
    if (_xmppStream==nil) {
        _xmppStream = [[XMPPStream alloc]init];
        [_xmppStream addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        _xmppStream.hostName=@"127.0.0.1";
        _xmppStream.hostPort=1280;
        
        
        
        
        [self addLog];
        
        // 添加心跳包
        _xmppAutoPing = [[XMPPAutoPing alloc]init];
        [_xmppAutoPing addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        // 设置响应服务器过来的心跳包.
        _xmppAutoPing.respondsToQueries=YES;
        _xmppAutoPing.pingInterval = 3600;
        _xmppAutoPing.pingTimeout  = 2;
        
        
        // 添加自动重连模块
        // 当服务器端,断开连接,后客户端可以自动重新连接服务器
        // 但是客户端自己断开连接的时候不会重连
        _xmppReconnect=[[XMPPReconnect alloc]init];
        [_xmppReconnect addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        _xmppReconnect.autoReconnect=YES; // 是否支持自动重连
        
        
        
        
        
        
        // 添加通讯录模块
        _xmppRoster = [[XMPPRoster alloc]initWithRosterStorage:[XMPPRosterCoreDataStorage sharedInstance]];
        _xmppRosterCoreDataStrorage =[XMPPRosterCoreDataStorage sharedInstance];
        [_xmppRoster addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        _xmppRoster.autoFetchRoster =NO;//添加模块完成后.直接向服务器搜索好友列表.默认就是YES;
//        [_xmppRoster fetchRoster]; //在自动清点好友被取消后,可以使用此方法来搜索好友信息;
        
        //添加聊天模块
        _xmppMessageArchiving = [[XMPPMessageArchiving alloc]initWithMessageArchivingStorage:[XMPPMessageArchivingCoreDataStorage sharedInstance]];
        _xmppMessageArchivingCoreDataStorage = [XMPPMessageArchivingCoreDataStorage sharedInstance];
//         消息模块 有addDelegate 方法,但事实上消息模块是没有代理方法的.
//        [_xmppMessageArchiving addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
        
        // 个人名片与头像(没有什么需要设置的属性)
        _xmppvCardTemp = [[XMPPvCardTempModule alloc]initWithvCardStorage:[XMPPvCardCoreDataStorage sharedInstance] dispatchQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        _xmppvCardAvatar = [[XMPPvCardAvatarModule alloc]initWithvCardTempModule:_xmppvCardTemp];
        _xmppvCardCoreDataStorage = [XMPPvCardCoreDataStorage sharedInstance];
        [_xmppvCardTemp addDelegate:self delegateQueue:dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)];
        

        
        // 添加文件接收模块
        _xmppIncomingFileTransfer = [[XMPPIncomingFileTransfer alloc]initWithDispatchQueue:dispatch_get_main_queue()];
        
        [_xmppIncomingFileTransfer addDelegate:self delegateQueue:dispatch_get_main_queue()];
        
        _xmppIncomingFileTransfer.autoAcceptFileTransfers = YES;
        

        
        
        // 激活心跳包
        [_xmppAutoPing activate:_xmppStream];
        [_xmppReconnect activate:_xmppStream];
        [_xmppRoster activate:_xmppStream];
        [_xmppMessageArchiving activate:_xmppStream];
        [_xmppvCardTemp activate:_xmppStream];
        [_xmppvCardAvatar activate:_xmppStream];
        [_xmppIncomingFileTransfer activate:_xmppStream];
    }
    return _xmppStream;
}



#pragma mark xmppStream的代理方法
// 成功连接到服务器进入这个代理
-(void)xmppStreamDidConnect:(XMPPStream *)sender{
    NSLog(@"成功连接到服务器");
    
    NSError *authenticateError;
    [self.xmppStream authenticateWithPassword:@"123456" error:&authenticateError];
    if (authenticateError!=nil) {
        NSLog(@"非代理的授权失败%@",authenticateError);
    }
    
    
    
    //        NSError *registerError;
    //        [self.xmppStream registerWithPassword:@"123456" error:&registerError];
    //        if (registerError!=nil) {
    //            NSLog(@"非代理的注册失败%@",registerError);
    //        }
    
}

// 连接超时的时候进入的方法
-(void)xmppStreamConnectDidTimeout:(XMPPStream *)sender{
    NSLog(@"连接超时");
}


#pragma 授权的代理方法
// 授权失败,进入这个代理
-(void)xmppStream:(XMPPStream *)sender didNotAuthenticate:(DDXMLElement *)error{
    NSLog(@"授权失败%@",error);
    
    
}

// 授权成功,进入此代理
- (void)xmppStreamDidAuthenticate:(XMPPStream *)sender{
    NSLog(@"授权成功");
    
    // 上线 kissXML 一个谷歌的框架
    //   <presence/>
    /**
     *  <presence type ="available">
     <show>away</show>
     away 离开
     chat 聊天
     dnd  正忙
     xa   离开很久
     
     <status>自定义信息</status>
     想使用status的自定义信息,发送给服务器的XML必须有show这个子节点
     不然status会无效
     </presence>
     */
    
    
    DDXMLElement *presence = [DDXMLElement elementWithName:@"presence"];
    [presence addAttributeWithName:@"type" stringValue:@"available"];
    
    DDXMLElement *show = [DDXMLElement elementWithName:@"show"];
    [show setStringValue:@"dnd"];
    
    DDXMLElement *status = [DDXMLElement elementWithName:@"status"];
    [status setStringValue:@"11111111"];
    
    //    [presence addChild:show];
    [presence addChild:status];
    
    
    
    [self.xmppStream sendElement:presence];
    //    [self.xmppStream sendElement:[XMPPPresence presence]];
    
    
//    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"WeView" bundle:nil];
//    [[[[UIApplication sharedApplication]delegate]window]setRootViewController:[storyBoard instantiateInitialViewController]];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        //跳转storyBoard
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"WeChat" bundle:nil];
        [[[[UIApplication sharedApplication]delegate]window]setRootViewController:storyBoard.instantiateInitialViewController];
    });

}


#pragma 注册的代理方法
// 注册失败,进入此代理方法
-(void)xmppStream:(XMPPStream *)sender didNotRegister:(DDXMLElement *)error{
    NSLog(@"注册失败:%@",error);
}

// 注册成功.进入此代理方法
-(void)xmppStreamDidRegister:(XMPPStream *)sender{
    NSLog(@"注册成功");
}

#pragma mark 心跳包的代理方法
//客户端发送给服务器ping消息时
- (void)xmppAutoPingDidSendPing:(XMPPAutoPing *)sender{
    NSLog(@"客户端发送给服务器ping消息时");
}

// 接收到服务器发送过来得ping信息
- (void)xmppAutoPingDidReceivePong:(XMPPAutoPing *)sender{
    NSLog(@"接收到服务器发送过来得ping信息");
}

// 如果服务器超时后,还没有响应客户端心跳包的请求
- (void)xmppAutoPingDidTimeout:(XMPPAutoPing *)sender{
    NSLog(@"十有八九断网了");
}



#pragma  mark 自动重连代理
// 在自动重连之前,需要做得操作.在这个代理方法中进行
- (void)xmppReconnect:(XMPPReconnect *)sender didDetectAccidentalDisconnect:(SCNetworkConnectionFlags)connectionFlags{
    NSLog(@"自动重连之前执行的语句");
}
// 通过一些判断,来决定是否自动连接
- (BOOL)xmppReconnect:(XMPPReconnect *)sender shouldAttemptAutoReconnect:(SCNetworkConnectionFlags)connectionFlags{
    NSLog(@"通过一些判断,来决定是否自动连接");
    return YES;
}


// kissXML 使用DOM 读取XML
-(void)CreateXML{
    /**
     *  <presence type ="available">
     <show>away</show>
     away 离开
     chat 聊天
     dnd  正忙
     xa   离开很久
     
     <status>自定义信息</status>
     </presence>
     <presence/> ==      *
     <presence type ="available">
     <show>away</show>
     away 离开
     chat 聊天
     dnd  正忙
     xa   离开很久
     
     <status>自定义信息</status>
     </presence> == <presence></presence>
     */
    // 创建一个名为presence节点(元素)
    DDXMLElement *presence = [DDXMLElement elementWithName:@"presence"];
    // 为presence节点 添加属性名为type 值为available
    [presence addAttributeWithName:@"type" stringValue:@"available"];
    
    // 创建一个节点
    DDXMLElement *show = [DDXMLElement elementWithName:@"show"];
    // 设置元素的值
    [show setStringValue:@"away"];
    
    DDXMLElement *status = [DDXMLElement elementWithName:@"status"];
    [status setStringValue:@"自定义信息"];
    
    // 为presence 节点添加子节点.
    [presence addChild:show];
    [presence addChild:status];
    
    //    -----------以上是创建,下面的代码是读取字符串-----------------
    
    // 获得presence 下所有子节点
    NSArray *arr = [presence elementsForName:@"show"];
    DDXMLElement *element=[arr lastObject];
    
    // 获得节点的值
    NSString *showString = [element stringValue];
    
    // 获得节点的属性
    DDXMLNode *node = [presence attributeForName:@"type"];
    // 获得属性值
    NSString *typeString = [node stringValue];
    
    
    //DOM -把XML整个读取到内存中后,读取中间的元素或属性
    //优点有点:可随意读取
    //缺点是占内存.
    //一般是简短的XML使用这种方式
    //SAX -把XML分段按顺序读取
    //优点:内存占用的少
    //缺点:就不可随意读取.需要按顺序读取
    //一般XML字符多的时候使用
}
// 添加日志记录
-(void)addLog{
    // 日志功能
    [DDLog addLogger:[DDTTYLogger sharedInstance] withLogLevel:XMPP_LOG_FLAG_SEND_RECV];
    /**
     *  如果需要设置颜色
     1.代码设置颜色能够设置
     2.需要安装控制台颜色插件(XcodeColors)注意:插件能不能使用和版本有关
     3.工程需要设置:
     工程Target->点击->Edit Scheme
     选择 run->
     选择 Arguments ->
     Environment Variables
     添加 name:XcodeColors value:YES
     注意:一个字母不能错.
     
     */
    [DDTTYLogger sharedInstance].colorsEnabled=YES;
    [[DDTTYLogger sharedInstance] setForegroundColor:[UIColor redColor] backgroundColor:[UIColor whiteColor] forFlag:XMPP_LOG_FLAG_SEND];
    [[DDTTYLogger sharedInstance] setForegroundColor:[UIColor blueColor] backgroundColor:[UIColor whiteColor] forFlag:XMPP_LOG_FLAG_RECV_POST];
}



#pragma mark - 通讯录代理方法
//// 当别人想添加你的时候,会调用这个方法.
//- (void)xmppRoster:(XMPPRoster *)sender didReceivePresenceSubscriptionRequest:(XMPPPresence *)presence{
////    // 接受来着...jid的订阅请求
////    [self.xmppRoster acceptPresenceSubscriptionRequestFrom:presence.from andAddToRoster:YES];
////    // 取消订阅
////    [self.xmppRoster removeUser:presence.from];
////    // 添加订阅
////    [self.xmppRoster addUser:presence.from withNickname:@""];
//    
//    
//    NSLog(@"当别人想添加你的时候,会调用这个方法. %@",presence);
//    
//    [self.xmppRoster acceptPresenceSubscriptionRequestFrom:presence.from andAddToRoster:YES];
//    
//}
//
//// 别人添加你好友,别人取消订阅,都会进入此方法
//- (void)xmppRoster:(XMPPRoster *)sender didReceiveRosterPush:(XMPPIQ *)iq{
//    
//}



// 通过服务器发送过来的 presence 节点来判断
//    type = subscribe 别人添加你好友
//    type = unsubscribe 别人取消你的订阅信息
- (void)xmppStream:(XMPPStream *)sender didReceivePresence:(XMPPPresence *)presence{
    if([presence.type isEqualToString:@"subscribe"]){
          NSLog(@"当别人想添加你的时候,会进入这个判断. %@",presence);
        [self.xmppRoster acceptPresenceSubscriptionRequestFrom:presence.from andAddToRoster:YES];
        
    }
    if([presence.type isEqualToString:@"unsubscribe"]){
        NSLog(@"当别人想取消你的订阅信息的时候,会进入这个判断. %@",presence);
        [self.xmppRoster removeUser:presence.from];
    }
}

#pragma mark  个人名片代理
// 接收到别人的个人名片时调用
- (void)xmppvCardTempModule:(XMPPvCardTempModule *)vCardTempModule
        didReceivevCardTemp:(XMPPvCardTemp *)vCardTemp
                     forJID:(XMPPJID *)jid{

}

// 更新自己的个人名片时调用
- (void)xmppvCardTempModuleDidUpdateMyvCard:(XMPPvCardTempModule *)vCardTempModule{

}

// 更新自己的个人名片失败时调用
- (void)xmppvCardTempModule:(XMPPvCardTempModule *)vCardTempModule failedToUpdateMyvCard:(NSXMLElement *)error{

}

#pragma mark  头像代理
// 接收到别人的头像更新
- (void)xmppvCardAvatarModule:(XMPPvCardAvatarModule *)vCardTempModule
              didReceivePhoto:(UIImage *)photo
                       forJID:(XMPPJID *)jid{

}



#pragma mark  接收文件代理
// 接收文件出错.进入此代理方法
- (void)xmppIncomingFileTransfer:(XMPPIncomingFileTransfer *)sender
                didFailWithError:(NSError *)error{
    
}

XMPPJID *fromFileJID;
// 当有接收文件求情时进入此代理方法.
- (void)xmppIncomingFileTransfer:(XMPPIncomingFileTransfer *)sender
               didReceiveSIOffer:(XMPPIQ *)offer{
    fromFileJID = offer.from;
}

// 接收文件代理方法
- (void)xmppIncomingFileTransfer:(XMPPIncomingFileTransfer *)sender
              didSucceedWithData:(NSData *)data
                           named:(NSString *)name{
    
    // 1.保存文件
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    path = [path stringByAppendingPathComponent:name];
    
    [data writeToFile:path atomically:YES];
    
    // 2.自己创建message消息.保存到消息表中
    XMPPMessage *message = [XMPPMessage messageWithType:@"chat" to:_xmppStream.myJID];
    
    [message addAttributeWithName:@"from" stringValue:fromFileJID.bare];
    
    [message addBody:path];
    
    // 3.保存到数据库中
    [[XMPPMessageArchivingCoreDataStorage sharedInstance] archiveMessage:message outgoing:NO xmppStream:_xmppStream];
    
    // 4.刷新对话框
    [[NSNotificationCenter defaultCenter] postNotificationName:@"NewMessage" object:nil];
    
    
    
}




@end
