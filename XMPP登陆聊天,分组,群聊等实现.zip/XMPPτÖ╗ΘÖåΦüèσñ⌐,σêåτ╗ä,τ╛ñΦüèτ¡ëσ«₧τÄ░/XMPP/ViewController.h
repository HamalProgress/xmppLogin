//
//  ViewController.h
//  XMPP
//
//  Created by wzhmac on 15/8/19.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

