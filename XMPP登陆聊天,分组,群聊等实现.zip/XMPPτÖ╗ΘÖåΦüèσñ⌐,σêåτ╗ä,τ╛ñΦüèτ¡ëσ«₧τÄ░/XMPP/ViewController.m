//
//  ViewController.m
//  XMPP
//
//  Created by wzhmac on 15/8/19.
//  Copyright (c) 2015年 wzhmac. All rights reserved.
//

#import "ViewController.h"

#import "DDLog.h"
#import "DDTTYLogger.h"
#import "XMPPLogging.h"

#import "CZXMPPTool.h"
@interface ViewController ()

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
//
//    /**
//     
//     登录步骤
//     *  1.连接服务器
//            使用xmppStream这个关键类.
//            初始化是需要设置代理,以及主机,与端口号.
//            如果没有设置myJID 是不会连接服务器的.
//     
//        2.授权         3.上线
//     
//     
//     
//     注册步骤
//      1.连接服务器
//     使用xmppStream这个关键类.
//     初始化是需要设置代理,以及主机,与端口号.
//     如果没有设置myJID 是不会连接服务器的.
//     
//     2. 注册
//        带内:通过socket 连接,来进行的注册
//        带外:不通过socket来进行的连接
//        服务器设置中,如果不允许带内注册,则注册时,不会有任何反应,*程序不会报错.
//        要和后台确认好;
//     */
    NSError *error;
//
    XMPPJID *myJID =  [XMPPJID jidWithUser:@"zhangsan" domain:@"itcast.cn" resource:@"iOS"];;
//    [XMPPJID jidWithString:@"zhangsan@itcast.cn"];
//    [XMPPJID jidWithString:@"zhangsan@itcast.cn" resource:@"iOS"];
//    [XMPPJID jidWithUser:@"zhangsan" domain:@"itcast.cn" resource:@"iOS"];
    
//    self.xmppStream.myJID=myJID;
//    // 连接服务器
//    [self.xmppStream connectWithTimeout:XMPPStreamTimeoutNone error:&error];
    
    
    
   [CZXMPPTool shardInstance].xmppStream.myJID=myJID;
    // 连接服务器
    [[CZXMPPTool shardInstance].xmppStream connectWithTimeout:XMPPStreamTimeoutNone error:&error];
    if (error!=nil) {
        NSLog(@"%@",error);
    }

//    [self CreateXML];
    NSLog(@"沙盒路径:%@", [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject]);
    
}

@end
