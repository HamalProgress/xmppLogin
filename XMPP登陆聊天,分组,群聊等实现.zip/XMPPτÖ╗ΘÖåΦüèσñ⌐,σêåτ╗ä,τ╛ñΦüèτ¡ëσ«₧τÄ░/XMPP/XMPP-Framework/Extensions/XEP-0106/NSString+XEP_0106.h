#import <Foundation/Foundation.h>

@interface NSString (XEP_0106)

- (NSString *)jidEscapedString;

- (NSString *)jidUnescapedString;

@end
